// Place your application-specific JavaScript functions and classes here
// require jquery
// require jquery_ujs
;